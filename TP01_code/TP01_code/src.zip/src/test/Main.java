package test;

import modele.Assistant;
import modele.EtudiantPleinTemps;
import modele.EtudiantTempsPartiel;
import modele.Professeur;

import java.util.ArrayList;

public class Main {

    public static void main(String[] args){
        ArrayList list = new ArrayList();
        list.add(new EtudiantPleinTemps("Leo", "Reed", "Mardi 10h15"));
        list.add(new EtudiantTempsPartiel("Linda", "Knight", "Mardi 13h15", "jeudi"));
        list.add(new Assistant("Cameron", "Hurst", 6000, "Programmation"));
        list.add(new Professeur("Edward", "Price", 10000, "Comptabilité"));
        list.add(new EtudiantPleinTemps("Joseph", "James", "Mardi 13h15"));
        list.add(new EtudiantTempsPartiel("Lucy", "Hopkins", "Mardi 15h15", "mercredi"));
        list.add(new Assistant("Samantha", "Woodward", 7000, "Modélisation"));
        list.add(new Professeur("Adam", "Barrett", 15000, "Cisco"));
        list.add(new EtudiantPleinTemps("Fluvia", "Giordano", "Mardi 10h15"));
        list.add(new EtudiantTempsPartiel("Elio", "Baresi", "Mardi 15h15", "vendredi"));
        list.add(new EtudiantPleinTemps("Dani", "Sjörberg", "Mardi 13h15"));
        list.add(new EtudiantTempsPartiel("Atle", "Ström", "Mardi 10h15", "lundi"));

        for (Object o : list){
            switch (o.getClass().getSimpleName()){
                case "EtudiantPleinTemps":
                    ((EtudiantPleinTemps)o).informationAAfficher();
                    break;
                case "EtudiantTempsPartiel":
                    ((EtudiantTempsPartiel)o).printInformation();
                    break;
                case "Professeur":
                    ((Professeur)o).getInformation();
                    break;
                case "Assistant":
                    ((Assistant)o).afficherInformation();
                    break;
                default:
                    break;
            }
        }

    }
}
