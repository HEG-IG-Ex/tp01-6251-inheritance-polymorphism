package modele;

public class EtudiantTempsPartiel {
    private String prenom;
    private String nom;
    private String horaireCours;
    private String horaireTravail;

    public EtudiantTempsPartiel(String prenom, String nom, String horaireCours, String horaireTravail){
        this.prenom = prenom;
        this.nom = nom;
        this.horaireCours = horaireCours;
        this.horaireTravail = horaireTravail;
    }

    public String getPrenom() {return prenom;}
    public void setPrenom(String prenom) {this.prenom = prenom;}
    public String getNom() {return nom;}
    public void setNom(String nom) {this.nom = nom;}
    public String getHoraireCours() {return horaireCours;}
    public void setHoraireCours(String horaireCours) {this.horaireCours = horaireCours;}

    public void printInformation(){
        System.out.println("Je m'appelle "+this.nom+" "+this.prenom+", suis étudiant(e) à temps partiel au cours de modélisation le "+this.horaireCours+" et travail le "+horaireTravail);
    }
}
