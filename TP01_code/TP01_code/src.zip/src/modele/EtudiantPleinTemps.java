package modele;

public class EtudiantPleinTemps {

    private String prenom;
    private String nom;
    private String horaire;

    public EtudiantPleinTemps(String prenom, String nom, String horaire){
        this.prenom = prenom;
        this.nom = nom;
        this.horaire = horaire;
    }

    public String getPrenom() {return prenom;}
    public void setPrenom(String prenom) {this.prenom = prenom;}
    public String getNom() {return nom;}
    public void setNom(String nom) {this.nom = nom;}
    public String getHoraire() {return horaire;}
    public void setHoraire(String horaire) {this.horaire = horaire;}

    public void informationAAfficher(){
        System.out.println("Je m'appelle "+this.nom+" "+this.prenom+" et suis étudiant(e) à plein temps au cours de modélisation le "+this.horaire);
    }
}
